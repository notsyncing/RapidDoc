// Copyright (C) 2018-2026 Intel Corporation
// SPDX-License-Identifier: Apache-2.0
//

#pragma once

#include "openvino/frontend/visibility.hpp"
#include "openvino/op/util/framework_node.hpp"

namespace ov {
namespace frontend {

/// \brief SequenceMark serves to mark places that require a sequence type propagation.
/// This class represents list or tuple constructs in frameworks like PyTorch, ONNX, etc.
/// It holds a collection of tensors that form a sequence.
class FRONTEND_API SequenceMark : public ov::op::util::FrameworkNode {
public:
    OPENVINO_OP("SequenceMark", "util", ov::op::util::FrameworkNode);

    SequenceMark(const ov::OutputVector& inputs);

    void validate_and_infer_types() override;
    std::shared_ptr<Node> clone_with_new_inputs(const OutputVector& inputs) const override;

    size_t size() const;
    bool empty() const;
    ov::Output<ov::Node> get_element(size_t index) const;

    /// \brief Returns all sequence elements of this SequenceMark, flattening any
    /// SequenceInsert / SequenceErase chain (with statically known positions)
    /// and unwrapping Identity passthrough. A directly nested SequenceMark input
    /// is kept as a single opaque element, preserving the index->element mapping
    /// expected by tuple/list unpack and getitem. An Insert/Erase with a
    /// non-constant position, or a producer that carries a sequence across a
    /// Loop/If boundary, is also treated as a single opaque element.
    ov::OutputVector get_sequence() const;
};

}  // namespace frontend
}  // namespace ov
